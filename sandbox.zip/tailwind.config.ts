// tailwind.config.js
export const content = ["./app/**/*.{js,ts,jsx,tsx}"];
export const theme = {
  extend: {},
};
export const plugins = [];
