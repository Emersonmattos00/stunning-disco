import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

export default NextAuth({
  providers: [
    CredentialsProvider({
      name: "Email/Senha",
      credentials: {
        email: {
          label: "Email",
          type: "text",
          placeholder: "exemplo@dominio.com",
        },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        // Substituir por lógica real de autenticação
        if (credentials.email && credentials.password) {
          return { id: "1", name: "Autor Exemplo", email: credentials.email };
        }
        return null;
      },
    }),
  ],
  pages: {
    signIn: "/auth/signin",
  },
});
